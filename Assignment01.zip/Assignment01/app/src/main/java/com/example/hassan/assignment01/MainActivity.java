package com.example.hassan.assignment01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NextActivity();
    }
    private void NextActivity(){
        android.widget.Button  nextb= (android.widget.Button) findViewById(R.id.b1button);
        nextb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new android.content.Intent(MainActivity.this,Main2Activity.class));
            }
        });
    }
}
